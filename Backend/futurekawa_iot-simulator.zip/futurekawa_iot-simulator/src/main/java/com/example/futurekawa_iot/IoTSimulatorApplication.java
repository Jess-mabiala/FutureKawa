package main.java.com.example.futurekawa_iot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class IoTSimulatorApplication {
    public static void main(String[] args) {
        SpringApplication.run(IoTSimulatorApplication.class, args);
    }
}